import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { buildPageHtml, getSiteContext, removeRepeatedSections } from './site-utils.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, '..');

/** Coding model that does not require organization verification. Reads images and returns structured edits. */
export const OPENAI_CHAT_MODEL = 'gpt-4.1-mini';

export function openAiChatBody({ messages, maxTokens = 4000, json = false, model = OPENAI_CHAT_MODEL }) {
  const body = {
    model,
    messages,
    max_completion_tokens: maxTokens,
    temperature: 0.2,
  };
  if (json) body.response_format = { type: 'json_object' };
  return body;
}

export function loadEnvKey() {
  const key = process.env.OPENAI_API_KEY;
  if (key) return key;

  const envPath = path.join(ROOT, '.env');
  if (!fs.existsSync(envPath)) return '';
  const line = fs.readFileSync(envPath, 'utf8')
    .split('\n')
    .find((l) => l.startsWith('OPENAI_API_KEY='));
  return line ? line.split('=').slice(1).join('=').trim() : '';
}

function stripCodeFences(text) {
  return text
    .replace(/^```html?\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();
}

const PHONE_RE = /(?:\+\d{1,3}[\s.-])?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}/g;
const EMAIL_RE = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
const IMAGE_EXT = /\.(png|jpe?g|webp|gif|svg)$/i;
const SKIP_IMAGE = /logo|favicon|fav\.|sprite|icon-|pay-logo|social|invoice|footer\.png|brand\//i;

/**
 * Photographs and graphics that actually exist in the clone.
 * Generated pages may only point at these, because invented filenames render
 * as broken icons.
 */
function listContentImages(siteDir) {
  const found = [];
  const seen = new Set();
  const roots = ['images', 'assets/images', 'assets/img', 'img'].map((rel) => path.join(siteDir, rel));

  function walk(dir, relBase) {
    if (!fs.existsSync(dir)) return;
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (entry.name.startsWith('.')) continue;
      const abs = path.join(dir, entry.name);
      const rel = `${relBase}/${entry.name}`;
      if (entry.isDirectory()) {
        if (/^(external|node_modules|brand)$/i.test(entry.name)) continue;
        walk(abs, rel);
        continue;
      }
      if (!IMAGE_EXT.test(entry.name) || SKIP_IMAGE.test(rel)) continue;
      let size = 0;
      try { size = fs.statSync(abs).size; } catch { continue; }
      if (size < 8 * 1024) continue;
      const key = entry.name.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      found.push({ rel, size });
    }
  }

  for (const dir of roots) walk(dir, path.relative(siteDir, dir).split(path.sep).join('/'));
  found.sort((a, b) => b.size - a.size);
  return found.map((item) => item.rel);
}

function imageExists(siteDir, src) {
  const clean = String(src || '').split('#')[0].split('?')[0];
  if (!clean || /^(https?:|data:|\/\/)/i.test(clean)) return true;
  const rel = clean.replace(/^(?:\.\/)+/, '').replace(/^\/+/, '');
  if (!rel || rel.split('/').includes('..')) return false;
  return fs.existsSync(path.join(siteDir, rel));
}

function imageKind(siteDir) {
  const photos = [];
  const icons = [];
  for (const rel of listContentImages(siteDir)) {
    const size = fs.statSync(path.join(siteDir, rel)).size;
    // Small PNGs are the icon tiles. Photographs are the large JPG and WebP files.
    if (/\.png$/i.test(rel) && size < 150 * 1024) icons.push(rel);
    else photos.push(rel);
  }
  return { photos, icons };
}

const IMAGE_FIT_STYLE = `<style data-cloner-image-fit>
.cloner-generated-page .elementor-widget-wrap { display: flex !important; flex-direction: column !important; align-items: stretch !important; width: 100% !important; }
.cloner-generated-page .elementor-widget { width: 100% !important; max-width: 100% !important; }
.cloner-generated-page .elementor-container { display: flex !important; flex-wrap: wrap !important; width: 100%; }
.cloner-generated-page .elementor-col-50 { width: 50% !important; flex: 0 0 50% !important; max-width: 50% !important; }
.cloner-generated-page .elementor-col-25 { width: 25% !important; flex: 0 0 25% !important; max-width: 25% !important; }
.cloner-generated-page .elementor-col-100 { width: 100% !important; flex: 0 0 100% !important; }
.cloner-generated-page .elementor-section { padding: 40px 0; }
.elementor-widget-image img { width: 100%; height: auto; max-height: 460px; display: block; object-fit: cover; border-radius: 8px; }
.elementor-widget-image-box .elementor-image-box-wrapper { text-align: center; }
.elementor-widget-image-box .elementor-image-box-img { width: 25%; margin: 0 auto 20px; }
.elementor-widget-image-box .elementor-image-box-img img { width: 100%; height: auto; display: block; }
.elementor-widget-image-box .elementor-image-box-img:has(img.cloner-photo-tile) { width: 100%; margin: 0 auto 16px; }
.elementor-widget-image-box .elementor-image-box-img img.cloner-photo-tile { width: 100%; height: 180px; object-fit: cover; border-radius: 8px; }
@media (max-width: 767px) {
  .cloner-generated-page .elementor-col-50,
  .cloner-generated-page .elementor-col-25 { width: 100% !important; flex: 0 0 100% !important; max-width: 100% !important; }
}
</style>`;

/**
 * Point every missing picture at a real file from the clone, and size image
 * tiles the way the Home page does. Elementor stores that size on per-widget
 * ids the generated page does not have, so without this the icons fill the column.
 */
export function rewriteMissingImages(siteDir, html) {
  const { photos, icons } = imageKind(siteDir);
  const all = [...photos, ...icons];
  if (!all.length) return html;

  const cursors = { photo: 0, icon: 0, any: 0 };
  const used = new Set();
  const iconSet = new Set(icons);
  const photoSet = new Set(photos);

  function take(pool, key) {
    for (let step = 0; step < pool.length; step += 1) {
      const candidate = pool[(cursors[key] + step) % pool.length];
      if (!used.has(candidate)) {
        cursors[key] += step + 1;
        used.add(candidate);
        return candidate;
      }
    }
    const candidate = pool[cursors[key] % pool.length];
    cursors[key] += 1;
    return candidate;
  }

  const rewritten = html.replace(/<img\b[^>]*>/gi, (tag, offset) => {
    const src = (tag.match(/\bsrc\s*=\s*["']([^"']+)["']/i) || [])[1] || '';
    const rel = String(src).split('#')[0].split('?')[0].replace(/^(?:\.\/)+/, '').replace(/^\/+/, '');
    const before = html.slice(Math.max(0, offset - 500), offset);
    const inIcon = /elementor-image-box/.test(before);
    const missing = !imageExists(siteDir, src);
    // A small site icon in the hero is the wrong picture. Photographs that exist stay where the page put them.
    const wrongKind = !inIcon && iconSet.has(rel) && photos.length;
    const repeatedIcon = inIcon && iconSet.has(rel) && used.has(rel);
    if (!missing && !wrongKind && !repeatedIcon) {
      if (iconSet.has(rel) || photoSet.has(rel)) used.add(rel);
      if (inIcon && photoSet.has(rel)) return markPhotoTile(tag);
      return tag;
    }

    let pool = all;
    let key = 'any';
    if (inIcon && icons.length) {
      pool = icons;
      key = 'icon';
    } else if (!inIcon && photos.length) {
      pool = photos;
      key = 'photo';
    }
    const next = take(pool, key);
    const nextTag = /\bsrc\s*=/i.test(tag)
      ? tag.replace(/\bsrc\s*=\s*["'][^"']*["']/i, `src="${next}"`)
      : tag.replace(/<img\b/i, `<img src="${next}"`);
    if (inIcon && photoSet.has(next)) return markPhotoTile(nextTag);
    return nextTag;
  });

  if (rewritten.includes('data-cloner-image-fit')) {
    return rewritten.replace(/<style data-cloner-image-fit>[\s\S]*?<\/style>/, IMAGE_FIT_STYLE);
  }
  if (/<\/head>/i.test(rewritten)) return rewritten.replace(/<\/head>/i, `${IMAGE_FIT_STYLE}\n</head>`);
  return `${IMAGE_FIT_STYLE}\n${rewritten}`;
}

function markPhotoTile(tag) {
  if (/cloner-photo-tile/.test(tag)) return tag;
  if (/\bclass\s*=/i.test(tag)) return tag.replace(/\bclass\s*=\s*(["'])/i, 'class=$1cloner-photo-tile ');
  return tag.replace(/<img\b/i, '<img class="cloner-photo-tile"');
}

/** Contact details already printed on the home page, so a new page never invents them. */
function contactFacts(html) {
  const emails = [...new Set(html.match(EMAIL_RE) || [])].slice(0, 6);
  const phones = [...new Set(html.match(PHONE_RE) || [])].slice(0, 6);
  const lines = [];
  if (emails.length) lines.push(`Email: ${emails.join(', ')}`);
  if (phones.length) lines.push(`Phone: ${phones.join(', ')}`);
  return lines.length ? lines.join('\n') : 'None found. Use clear placeholders. Do not invent an email, phone, or address.';
}

/** Page generation tries the strongest coding model first, then the models this project already uses. */
const PAGE_MODELS = ['gpt-6-astra', 'gpt-4.1', OPENAI_CHAT_MODEL];

function pageSlug(pageName) {
  return String(pageName || 'page')
    .trim()
    .toLowerCase()
    .replace(/\.php$/i, '')
    .replace(/\.html?$/i, '')
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9_-]/g, '') || 'page';
}

function parseModelJson(raw) {
  const text = stripCodeFences(raw);
  try {
    return JSON.parse(text);
  } catch {
    const start = text.indexOf('{');
    const end = text.lastIndexOf('}');
    if (start >= 0 && end > start) return JSON.parse(text.slice(start, end + 1));
    throw new Error('The model did not return a page.');
  }
}

async function chatCompletion(apiKey, body) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) {
    const err = new Error(data.error?.message || `OpenAI API error (${res.status})`);
    err.code = data.error?.code || '';
    throw err;
  }
  return data.choices?.[0]?.message?.content || '';
}

async function requestImagePng(apiKey, body) {
  const res = await fetch('https://api.openai.com/v1/images/generations', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error?.message || `Image generation failed (${res.status})`);
  const b64 = data.data?.[0]?.b64_json;
  if (!b64) throw new Error('Image generation returned no image.');
  return Buffer.from(b64, 'base64');
}

export async function generateImagePng(apiKey, prompt, size) {
  const body = {
    model: 'gpt-image-1',
    prompt: String(prompt).slice(0, 800),
    n: 1,
    size,
    quality: 'medium',
  };
  try {
    return await requestImagePng(apiKey, body);
  } catch (err) {
    if (!/quality|unknown parameter/i.test(err.message)) throw err;
    delete body.quality;
    return requestImagePng(apiKey, body);
  }
}

function upsertMarkedBlock(file, slug, body) {
  const text = String(body || '').trim();
  const start = `/* cloner-page:${slug} */`;
  const end = `/* /cloner-page:${slug} */`;
  const block = `${start}\n${text}\n${end}\n`;
  const current = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
  const pattern = new RegExp(`\\n*/\\* cloner-page:${slug} \\*/[\\s\\S]*?/\\* /cloner-page:${slug} \\*/\\n?`);
  if (!text) {
    if (pattern.test(current)) fs.writeFileSync(file, current.replace(pattern, '\n'));
    return;
  }
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, pattern.test(current) ? current.replace(pattern, `\n${block}`) : `${current.trimEnd()}\n\n${block}`);
}

function firstMatch(html, pattern) {
  const match = String(html || '').match(pattern);
  return match ? match[0] : '';
}

function layoutExamples(indexHtml) {
  const hero = firstMatch(indexHtml, /<section class="hero_sec"[\s\S]*?<\/section>/i).slice(0, 1800);
  const cards = firstMatch(indexHtml, /<div class="elementor-image-box-wrapper"[\s\S]*?<\/div>\s*<\/div>/i).slice(0, 1100);
  const contact = (indexHtml.match(/href=(["'])([^"']*contact[^"']*)\1/i) || [])[2] || '';
  return { hero, cards, contact };
}

function plainText(html) {
  return String(html || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[ch]));
}

function siteButton(label, href) {
  const text = escapeHtml(plainText(label) || 'Contact Us');
  const target = href || '#';
  return `<div class="button_head right"><span><a href="${target}"><button class="btn btn-dark" type="button">${text}</button></a></span></div>`;
}

function fillHero(heroHtml, title, paragraph) {
  let hero = heroHtml;
  if (/<h2\b/i.test(hero)) {
    hero = hero.replace(/(<h2\b[^>]*>)[\s\S]*?(<\/h2>)/i, `$1${escapeHtml(title)}$2`);
  }
  if (/<p\b/i.test(hero)) {
    hero = hero.replace(/(<p\b[^>]*>)[\s\S]*?(<\/p>)/i, `$1${escapeHtml(paragraph)}$2`);
  }
  return hero;
}

/** Make generated markup use the Home page banner, buttons, and stacked columns. */
export function polishGeneratedMain(mainHtml, { title, indexHtml }) {
  const { hero, contact } = layoutExamples(indexHtml);
  let html = String(mainHtml || '').replace(/\sstyle=(["'])(?:(?!\1).)*\1/gi, '');
  html = html.replace(/<a\b[^>]*class=(["'])[^"']*\bbtn\b[^"']*\1[^>]*>[\s\S]*?<\/a>/gi, (tag) => {
    if (/<button\b/i.test(tag)) return tag;
    const href = (tag.match(/\bhref=(["'])([^"']*)\1/i) || [])[2];
    const target = !href || href === '#contact' || href.startsWith('#') ? contact : href;
    return siteButton(plainText(tag), target);
  });
  if (hero && !/class=(["'])[^"']*\bhero_sec\b/.test(html)) {
    const paragraph = plainText((html.match(/<p\b[^>]*>([\s\S]*?)<\/p>/i) || [])[1] || '');
    html = `${fillHero(hero, title, paragraph)}\n${html}`;
  }
  return removeRepeatedSections(`<main>${html}</main>`).html.replace(/^<main>|<\/main>$/g, '');
}

function insertNavItem(html, href, label) {
  if (html.includes(`href="${href}"`)) return html;
  const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const sameLabel = new RegExp(
    `(<li>\\s*<a [^>]*href=")[^"]*("[^>]*>\\s*)${escaped}(\\s*</a>\\s*</li>)`,
    'i',
  );
  if (sameLabel.test(html)) return html.replace(sameLabel, `$1${href}$2${label}$3`);
  const item = `<li><a href="${href}">${label}</a></li>`;
  return html.replace(/(<li>\s*<a [^>]*>\s*Home\s*<\/a>\s*<\/li>)/i, `$1\n                        ${item}`);
}

function addPageToHeaders(siteDir, slug, label) {
  const safeLabel = String(label || slug).replace(/[<>]/g, '');
  const headerPhp = path.join(siteDir, 'includes/header.php');
  if (fs.existsSync(headerPhp)) {
    const html = fs.readFileSync(headerPhp, 'utf8');
    fs.writeFileSync(headerPhp, insertNavItem(html, `/${slug}/`, safeLabel));
  }
  const pages = [];
  function walk(dir, rel = '') {
    if (!fs.existsSync(dir)) return;
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (entry.name.startsWith('.') || ['external', 'node_modules', 'views', 'includes'].includes(entry.name)) continue;
      const nextRel = rel ? `${rel}/${entry.name}` : entry.name;
      if (entry.isDirectory()) walk(path.join(dir, entry.name), nextRel);
      else if (/\.html?$/i.test(entry.name)) pages.push(nextRel);
    }
  }
  walk(siteDir);
  for (const file of pages) {
    const abs = path.join(siteDir, file);
    const html = fs.readFileSync(abs, 'utf8');
    if (!/<ul class="main-menu"/.test(html)) continue;
    const depth = file.split('/').length - 1;
    const href = `${depth ? '../'.repeat(depth) : ''}${slug}.html`;
    const next = insertNavItem(html, href, safeLabel);
    if (next !== html) fs.writeFileSync(abs, next);
  }
}

function writePhpView(siteDir, slug, { title, description, mainHtml }) {
  const views = path.join(siteDir, 'views');
  if (!fs.existsSync(views)) return '';
  const phpMain = mainHtml
    .replace(/\bsrc=(["'])(?!https?:|\/|data:|#)([^"']+)\1/gi, 'src=$1/$2$1')
    .replace(/\bhref=(["'])(?!https?:|\/|data:|#|mailto:|tel:)([^"']+)\1/gi, 'href=$1/$2$1');
  const scriptFile = path.join(siteDir, 'js/script.js');
  const hasScript = fs.existsSync(scriptFile) && fs.readFileSync(scriptFile, 'utf8').trim();
  const php = `<!DOCTYPE html>
<html>
<?php include_once("includes/head.php"); ?>
<title>${title.replace(/</g, '')}</title>
<meta name="description" content="${String(description || '').replace(/"/g, '&quot;')}">
<body>
<?php include_once("includes/header.php"); ?>
<main data-cloner-page="main" class="cloner-generated-page">
${phpMain}
</main>
<?php include_once("includes/footer.php"); ?>
${hasScript ? '<script src="/js/script.js"></script>' : ''}
</body>
</html>
`;
  fs.writeFileSync(path.join(views, `${slug}.php`), php);
  const footer = path.join(siteDir, 'includes/footer.php');
  if (hasScript && fs.existsSync(footer)) {
    const text = fs.readFileSync(footer, 'utf8');
    if (!text.includes('/js/script.js')) {
      fs.writeFileSync(footer, text.replace('</footer>', '</footer>\n<script src="/js/script.js"></script>\n'));
    }
  }
  return `views/${slug}.php`;
}

export async function generatePageWithAI(siteDir, { pageName, pageTitle, prompt, description }) {
  const apiKey = loadEnvKey();
  if (!apiKey) {
    throw new Error('OPENAI_API_KEY is not set. Add it to a .env file in the project root.');
  }

  const ctx = getSiteContext(siteDir);
  const title = pageTitle || pageName.replace(/\.html?$/i, '').replace(/[-_]/g, ' ');
  const indexHtml = fs.readFileSync(path.join(siteDir, 'index.html'), 'utf8');

  const slug = pageSlug(pageName);
  const layout = layoutExamples(indexHtml);
  const systemPrompt = `You build one new page that looks like it was designed with the existing website. The text in "User request" is the requirement. Follow it. Reuse the Home page's sections, classes, buttons, and spacing. Do not invent a new visual theme, header, or footer.

Return one JSON object and nothing else:
{
  "pageTitle": "browser title",
  "navLabel": "short header label. Use the page title. Do not repeat a label already in the header.",
  "metaDescription": "one sentence",
  "mainHtml": "inner HTML only. No html, head, body, header, or footer.",
  "css": "",
  "js": "",
  "images": [{ "file": "kebab-case.png", "prompt": "a photograph with no text, letters, or watermark" }]
}

Rules:
- Open mainHtml with the Home page hero section. Keep every class. Replace only the heading and paragraph.
- Then add a two-column section: heading and paragraph stacked in the left column, one photograph in the right column. Use elementor-section, elementor-container, elementor-col-50, elementor-widget-heading, elementor-widget-text-editor, and elementor-widget-image.
- Then add a row of three cards using the Home page image-box markup. Each card has its own short heading and paragraph.
- Buttons must be copied from the hero: div.button_head.right > span > a > button.btn.btn-dark. Never put button_head or btn on the anchor itself.
- Point buttons at the contact page already on the site. Use only the contact details listed. Never invent an email, phone, or address.
- No inline style attributes. css and js stay empty unless the request asks for interaction. Do not insert header links in JavaScript.
- When the request asks for images, include one large photograph and two card photographs. Every img src is images/<file> using those exact file names.`;

  const userPrompt = `Page name: ${slug}.php
Page title: "${title}"

User request:
${prompt}

Colors already in use — primary ${ctx.theme.primary}, secondary ${ctx.theme.secondary}, accent ${ctx.theme.accent}, background ${ctx.theme.background || ''}, text ${ctx.theme.text || ''}.
Contact page: ${layout.contact || 'use the contact link from the hero'}

Contact details already on the Home page:
${contactFacts(indexHtml)}

Home page hero to copy:
${layout.hero || '(no hero section found; use a section with the site container and heading classes)'}

Home page card to copy for the row of three:
${layout.cards || '(no card found; use a heading, paragraph, and image in each column)'}

Home page content pattern:
${(ctx.mainSample || '').slice(0, 2200)}`;

  const messages = [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: userPrompt },
  ];
  let raw = '';
  let model = PAGE_MODELS[0];
  let lastError;
  for (const candidate of PAGE_MODELS) {
    model = candidate;
    try {
      const body = openAiChatBody({ model, maxTokens: 7000, json: true, messages });
      if (candidate !== 'gpt-4.1' && candidate !== OPENAI_CHAT_MODEL) delete body.temperature;
      raw = await chatCompletion(apiKey, body);
      lastError = null;
      break;
    } catch (err) {
      lastError = err;
      if (/api key|incorrect api key|quota|billing|rate limit|insufficient/i.test(err.message)) throw err;
    }
  }
  if (lastError) throw lastError;

  const page = parseModelJson(raw);
  let mainContent = String(page.mainHtml || '').trim();
  if (!mainContent) throw new Error('The model returned an empty page.');
  const wrapped = mainContent.match(/^<main\b[^>]*>([\s\S]*)<\/main>$/i);
  if (wrapped) mainContent = wrapped[1].trim();

  const images = Array.isArray(page.images) ? page.images.slice(0, 3) : [];
  const saved = await Promise.all(images.map(async (image) => {
    const file = String(image.file || '').replace(/[^a-z0-9._-]/gi, '').replace(/^\.+/, '');
    if (!file || !IMAGE_EXT.test(file)) return null;
    try {
      const png = await generateImagePng(
        apiKey,
        `${image.prompt || file}. Professional photograph, no text, no letters, no watermark.`,
        '1024x1024',
      );
      const pngName = file.replace(/\.\w+$/, '.png');
      for (const dir of ['images', 'assets/images']) {
        const folder = path.join(siteDir, dir);
        fs.mkdirSync(folder, { recursive: true });
        fs.writeFileSync(path.join(folder, pngName), png);
      }
      return { file, pngName };
    } catch (err) {
      console.warn('Page image skipped:', err.message);
      return null;
    }
  }));
  for (const item of saved) {
    if (item) mainContent = mainContent.replaceAll(`images/${item.file}`, `images/${item.pngName}`);
  }

  mainContent = polishGeneratedMain(mainContent, { title: page.pageTitle || title, indexHtml });
  mainContent = rewriteMissingImages(siteDir, mainContent);
  const finalTitle = page.pageTitle || title;
  const meta = page.metaDescription || description || '';
  const css = String(page.css || '');
  const js = String(page.js || '');
  for (const cssFile of ['css/style.css', 'assets/css/style.css']) {
    upsertMarkedBlock(path.join(siteDir, cssFile), slug, css);
  }
  for (const jsFile of ['js/script.js', 'assets/js/script.js']) {
    upsertMarkedBlock(path.join(siteDir, jsFile), slug, js);
  }

  const scriptFile = path.join(siteDir, 'js/script.js');
  const scriptTag = fs.existsSync(scriptFile) && fs.readFileSync(scriptFile, 'utf8').trim()
    ? '<script src="js/script.js"></script>\n'
    : '';
  const html = buildPageHtml({
    baseHtml: indexHtml,
    pageTitle: finalTitle,
    mainContent,
    metaDescription: meta,
  }).replace('</body>', `${scriptTag}</body>`);
  fs.writeFileSync(path.join(siteDir, `${slug}.html`), html);

  const phpFile = writePhpView(siteDir, slug, { title: finalTitle, description: meta, mainHtml: mainContent });
  addPageToHeaders(siteDir, slug, page.navLabel || finalTitle);

  return {
    file: `${slug}.html`,
    phpFile,
    label: finalTitle,
    model,
    preview: mainContent.slice(0, 500),
  };
}

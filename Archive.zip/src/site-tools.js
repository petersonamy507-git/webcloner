/** Theme, Add Page, and AI page generation for the visual editor */
import { API } from './api.js';

const THEME_ROLES = [
  { key: 'primary', picker: 'themePrimary', hex: 'themePrimaryHex' },
  { key: 'secondary', picker: 'themeSecondary', hex: 'themeSecondaryHex' },
  { key: 'accent', picker: 'themeAccent', hex: 'themeAccentHex' },
  { key: 'background', picker: 'themeBackground', hex: 'themeBackgroundHex' },
  { key: 'text', picker: 'themeText', hex: 'themeTextHex' },
];

function normalizeHex(value) {
  if (!value) return '';
  let hex = String(value).trim().toLowerCase();
  if (!hex.startsWith('#')) hex = `#${hex}`;
  if (/^#[0-9a-f]{3}$/i.test(hex)) {
    hex = `#${hex[1]}${hex[1]}${hex[2]}${hex[2]}${hex[3]}${hex[3]}`;
  }
  return /^#[0-9a-f]{6}$/i.test(hex) ? hex : '';
}

function hexToRgb(hex) {
  const h = normalizeHex(hex).slice(1);
  return {
    r: parseInt(h.slice(0, 2), 16),
    g: parseInt(h.slice(2, 4), 16),
    b: parseInt(h.slice(4, 6), 16),
  };
}

function channelLuma(value) {
  const s = value / 255;
  return s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
}

function relativeLuminance(hex) {
  const { r, g, b } = hexToRgb(hex);
  return (0.2126 * channelLuma(r)) + (0.7152 * channelLuma(g)) + (0.0722 * channelLuma(b));
}

function contrastRatio(foreground, background) {
  const a = relativeLuminance(foreground);
  const b = relativeLuminance(background);
  const lighter = Math.max(a, b);
  const darker = Math.min(a, b);
  return (lighter + 0.05) / (darker + 0.05);
}

function mixHex(from, to, amount) {
  const a = hexToRgb(from);
  const b = hexToRgb(to);
  const mix = (x, y) => Math.round(x + ((y - x) * amount));
  return `#${[mix(a.r, b.r), mix(a.g, b.g), mix(a.b, b.b)]
    .map((n) => n.toString(16).padStart(2, '0'))
    .join('')}`;
}

function withContrast(color, background, min = 4.5) {
  const bg = normalizeHex(background) || '#ffffff';
  const fg = normalizeHex(color) || (relativeLuminance(bg) > 0.4 ? '#111111' : '#ffffff');
  if (contrastRatio(fg, bg) >= min) return fg;
  const target = relativeLuminance(bg) > 0.4 ? '#111111' : '#ffffff';
  for (let step = 1; step <= 8; step += 1) {
    const next = mixHex(fg, target, step / 8);
    if (contrastRatio(next, bg) >= min) return next;
  }
  return contrastRatio('#111111', bg) >= contrastRatio('#ffffff', bg) ? '#111111' : '#ffffff';
}

export function initSiteTools({ folder, previewFrame, pageSelect, loadPages, loadPreview, showSaveToast }) {
  let themeBaseline = null;
  let themeModal;

  function themeBaselineFrom(theme) {
    return {
      primary: normalizeHex(theme?.primary) || '#513f29',
      secondary: normalizeHex(theme?.secondary) || '#ff6900',
      accent: normalizeHex(theme?.accent) || '#203d8d',
      background: normalizeHex(theme?.background) || '#e8e8e8',
      text: normalizeHex(theme?.text) || '#333333',
    };
  }
  let addPageModal;
  let aiPageModal;
  let currentTheme = {};
  let activeRole = 'primary';
  let themeUiBound = false;

  function setStatus(el, msg, isError = false) {
    if (!el) return;
    el.textContent = msg;
    el.className = isError ? 'small text-danger mt-2' : 'small text-muted mt-2';
  }

  async function parseJsonResponse(res) {
    const text = await res.text();
    try {
      return JSON.parse(text);
    } catch {
      if (res.status === 404 || text === 'Not found') {
        throw new Error('API server needs a restart. Run: npm run api');
      }
      throw new Error(text || `Request failed (${res.status})`);
    }
  }

  function rolePicker(key) {
    return document.getElementById(THEME_ROLES.find((role) => role.key === key).picker);
  }

  function roleHex(key) {
    return document.getElementById(THEME_ROLES.find((role) => role.key === key).hex);
  }

  function readThemeForm() {
    return {
      primary: normalizeHex(rolePicker('primary').value) || '#1d4ed8',
      secondary: normalizeHex(rolePicker('secondary').value) || '#0f172a',
      accent: normalizeHex(rolePicker('accent').value) || '#f59e0b',
      background: normalizeHex(rolePicker('background').value) || '#ffffff',
      text: normalizeHex(rolePicker('text').value) || '#111827',
    };
  }

  function setRoleColor(key, color, { syncHex = true } = {}) {
    const hex = normalizeHex(color);
    if (!hex) return;
    const picker = rolePicker(key);
    const hexInput = roleHex(key);
    picker.value = hex;
    if (syncHex) hexInput.value = hex.toUpperCase();
  }

  function setActiveRole(key) {
    activeRole = key;
    document.querySelectorAll('.theme-role').forEach((el) => {
      el.classList.toggle('active', el.dataset.role === key);
    });
  }

  function updateThemePreview() {
    const theme = readThemeForm();
    const text = withContrast(theme.text, theme.background);
    const heading = withContrast(theme.primary, theme.background);
    const accent = withContrast(theme.accent, theme.background);
    const onPrimary = withContrast('#ffffff', theme.primary);
    const onSecondary = withContrast('#ffffff', theme.secondary);
    const preview = document.getElementById('themePreview');
    if (!preview) return;
    preview.style.setProperty('--theme-preview-bg', theme.background);
    preview.style.setProperty('--theme-preview-text', text);
    preview.style.setProperty('--theme-preview-heading', heading);
    preview.style.setProperty('--theme-preview-accent', accent);
    preview.style.setProperty('--theme-preview-primary', theme.primary);
    preview.style.setProperty('--theme-preview-on-primary', onPrimary);
    preview.style.setProperty('--theme-preview-secondary', theme.secondary);
    preview.style.setProperty('--theme-preview-on-secondary', onSecondary);

    const note = document.getElementById('themeContrast');
    if (!note) return;
    const ratio = contrastRatio(theme.text, theme.background);
    if (ratio >= 4.5) {
      note.className = 'theme-contrast-note small mt-3 is-ok';
      note.textContent = `Text contrast ${ratio.toFixed(1)}:1 — WCAG AA ready.`;
    } else {
      note.className = 'theme-contrast-note small mt-3 is-warn';
      note.textContent = `Text contrast ${ratio.toFixed(1)}:1 is too low. Apply Theme will auto-fix body text for readability.`;
    }
  }

  function fillThemeForm(theme) {
    setRoleColor('primary', theme.primary || '#1d4ed8');
    setRoleColor('secondary', theme.secondary || '#0f172a');
    setRoleColor('accent', theme.accent || '#f59e0b');
    setRoleColor('background', theme.background || '#ffffff');
    setRoleColor('text', theme.text || '#111827');

    const swatches = document.getElementById('themePalette');
    if (swatches) {
      const palette = theme.palette?.length
        ? theme.palette
        : [theme.primary, theme.secondary, theme.accent, theme.background, theme.text].filter(Boolean);
      swatches.innerHTML = palette.map((c) => {
        const color = normalizeHex(c);
        if (!color) return '';
        return `<button type="button" class="theme-swatch" data-color="${color}" title="${color.toUpperCase()}" style="background:${color}" aria-label="Use ${color}"></button>`;
      }).join('');
      swatches.querySelectorAll('.theme-swatch').forEach((btn) => {
        btn.addEventListener('click', () => {
          setRoleColor(activeRole, btn.dataset.color);
          updateThemePreview();
          setStatus(document.getElementById('themeStatus'), `Applied ${btn.dataset.color.toUpperCase()} to ${activeRole}.`);
        });
      });
    }

    setActiveRole(activeRole);
    updateThemePreview();
  }

  function bindThemeUi() {
    if (themeUiBound) return;
    themeUiBound = true;

    document.querySelectorAll('.theme-role').forEach((roleEl) => {
      roleEl.addEventListener('click', (e) => {
        if (e.target.closest('input')) return;
        setActiveRole(roleEl.dataset.role);
      });
    });

    THEME_ROLES.forEach(({ key, picker, hex }) => {
      const pickerEl = document.getElementById(picker);
      const hexEl = document.getElementById(hex);
      pickerEl?.addEventListener('input', () => {
        setActiveRole(key);
        hexEl.value = pickerEl.value.toUpperCase();
        updateThemePreview();
      });
      pickerEl?.addEventListener('focus', () => setActiveRole(key));
      hexEl?.addEventListener('focus', () => setActiveRole(key));
      hexEl?.addEventListener('input', () => {
        const next = normalizeHex(hexEl.value);
        if (!next) return;
        pickerEl.value = next;
        updateThemePreview();
      });
      hexEl?.addEventListener('blur', () => {
        const next = normalizeHex(hexEl.value) || pickerEl.value;
        hexEl.value = next.toUpperCase();
        pickerEl.value = next;
        updateThemePreview();
      });
      hexEl?.addEventListener('click', (e) => e.stopPropagation());
      pickerEl?.addEventListener('click', (e) => e.stopPropagation());
    });
  }

  async function openThemeModal() {
    try {
      bindThemeUi();
      const res = await fetch(API.theme(folder));
      const data = await parseJsonResponse(res);
      if (!data.success) throw new Error(data.error || 'Failed to load theme');
      currentTheme = data.theme;
      const opened = themeBaselineFrom(data.theme);
      themeBaseline = opened;
      fillThemeForm({ ...data.theme, ...opened });
      setStatus(document.getElementById('themeStatus'), '');
      themeModal.show();
    } catch (err) {
      alert(err.message);
    }
  }

  async function applyTheme() {
    const btn = document.getElementById('applyThemeBtn');
    const status = document.getElementById('themeStatus');
    btn.disabled = true;
    setStatus(status, 'Applying theme across the whole site...');

    const raw = readThemeForm();
    const theme = {};
    for (const key of ['primary', 'secondary', 'accent', 'background', 'text']) {
      const next = normalizeHex(raw[key]);
      const previous = themeBaseline?.[key];
      if (next && next !== previous) theme[key] = next;
    }
    if (!Object.keys(theme).length) {
      setStatus(status, 'Choose a new color. Nothing else on the site will change.');
      btn.disabled = false;
      return;
    }

    try {
      const res = await fetch(API.themePost, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ folder, theme }),
      });
      const data = await parseJsonResponse(res);
      if (!data.success) throw new Error(data.error || 'Theme apply failed');

      currentTheme = data.theme;
      themeModal.hide();
      loadPreview(pageSelect.value);
      showSaveToast?.('Theme applied across the site');
    } catch (err) {
      setStatus(status, err.message, true);
    } finally {
      btn.disabled = false;
    }
  }

  async function createPage() {
    const btn = document.getElementById('createPageBtn');
    const status = document.getElementById('addPageStatus');
    const pageName = document.getElementById('newPageName').value.trim();
    const title = document.getElementById('newPageTitle').value.trim();
    const template = document.getElementById('newPageTemplate').value;

    if (!pageName) {
      setStatus(status, 'Page name is required.', true);
      return;
    }

    btn.disabled = true;
    setStatus(status, 'Creating page...');

    try {
      const res = await fetch(API.createPage, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ folder, pageName, title, template }),
      });
      const data = await parseJsonResponse(res);
      if (!data.success) throw new Error(data.error || 'Failed to create page');

      await loadPages();
      pageSelect.value = data.page.file;
      loadPreview(data.page.file);
      addPageModal.hide();
      document.getElementById('newPageName').value = '';
      document.getElementById('newPageTitle').value = '';
      setStatus(status, '');
    } catch (err) {
      setStatus(status, err.message, true);
    } finally {
      btn.disabled = false;
    }
  }

  const DEFAULT_PAGE_EXAMPLE = {
    pageName: 'book-editing.php',
    pageTitle: 'Book Editing Services',
    prompt: `I need to add a new page named book-editing.php. The project structure should remain the same as the other existing pages:

assets/css/style.css — all CSS should be added here.
assets/images/ — all images should be placed here.
assets/js/script.js — all JavaScript should be added here.
The new page should follow the same structure and sections as the existing pages, but the content should be specifically written for Book Editing Services in a professional and engaging way.

Please use professional, high-quality book-editing-related images and maintain the same color theme, typography, styling, and overall visual identity that is already being used throughout the website.

The new page should look consistent with the rest of the website while having unique, professional content focused specifically on book editing.`,
  };

  function applyDefaultPageExample() {
    const name = document.getElementById('aiPageName');
    const title = document.getElementById('aiPageTitle');
    const prompt = document.getElementById('aiPagePrompt');
    if (name && !name.value.trim()) name.value = DEFAULT_PAGE_EXAMPLE.pageName;
    if (title && !title.value.trim()) title.value = DEFAULT_PAGE_EXAMPLE.pageTitle;
    if (prompt) prompt.value = DEFAULT_PAGE_EXAMPLE.prompt;
  }

  async function generateAiPage() {
    const btn = document.getElementById('generateAiPageBtn');
    const status = document.getElementById('aiPageStatus');
    const pageName = document.getElementById('aiPageName').value.trim();
    const pageTitle = document.getElementById('aiPageTitle').value.trim();
    const prompt = document.getElementById('aiPagePrompt').value.trim();

    if (!pageName || !prompt) {
      setStatus(status, 'Page name and prompt are required.', true);
      return;
    }

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Generating...';
    setStatus(status, 'Writing the page and creating the photos together. This usually takes about a minute.');

    try {
      const res = await fetch(API.generatePage, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ folder, pageName, pageTitle, prompt }),
      });
      const data = await parseJsonResponse(res);
      if (!data.success) throw new Error(data.error || 'AI generation failed');

      await loadPages();
      pageSelect.value = data.page.file;
      loadPreview(data.page.file);
      aiPageModal.hide();
      document.getElementById('aiPageName').value = '';
      document.getElementById('aiPageTitle').value = '';
      document.getElementById('aiPagePrompt').value = '';
      setStatus(status, '');
    } catch (err) {
      setStatus(status, err.message, true);
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<i class="bi bi-stars me-1"></i>Generate Page';
    }
  }

  function bind() {
    themeModal = new bootstrap.Modal(document.getElementById('themeModal'));
    addPageModal = new bootstrap.Modal(document.getElementById('addPageModal'));
    aiPageModal = new bootstrap.Modal(document.getElementById('aiPageModal'));
    bindThemeUi();

    document.getElementById('themeBtn')?.addEventListener('click', openThemeModal);
    document.getElementById('addPageBtn')?.addEventListener('click', () => addPageModal.show());
    document.getElementById('aiPageBtn')?.addEventListener('click', () => aiPageModal.show());
    document.getElementById('applyThemeBtn')?.addEventListener('click', applyTheme);
    document.getElementById('createPageBtn')?.addEventListener('click', createPage);
    document.getElementById('generateAiPageBtn')?.addEventListener('click', generateAiPage);
    document.getElementById('aiPageDefaultPrompt')?.addEventListener('click', applyDefaultPageExample);
    document.getElementById('refreshThemeBtn')?.addEventListener('click', async () => {
      const status = document.getElementById('themeStatus');
      setStatus(status, 'Re-detecting brand colors from the site CSS...');
      try {
        const res = await fetch(API.theme(folder, true));
        const data = await parseJsonResponse(res);
        if (!data.success) throw new Error(data.error);
        currentTheme = data.theme;
        fillThemeForm(data.theme);
        setStatus(status, 'Theme re-detected from the site.');
      } catch (err) {
        setStatus(status, err.message, true);
      }
    });
  }

  return { bind };
}

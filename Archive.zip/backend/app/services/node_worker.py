import asyncio
import json
from typing import Any

from app.config import ROOT


async def run_node_worker(action: str, **params: Any) -> dict:
    payload = json.dumps({"action": action, **params})
    proc = await asyncio.create_subprocess_exec(
        "node",
        str(ROOT / "server" / "worker.mjs"),
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=str(ROOT),
    )
    stdout, stderr = await proc.communicate(payload.encode())

    if not stdout:
        msg = stderr.decode().strip() or "Node worker failed"
        raise RuntimeError(msg)

    result = json.loads(stdout.decode())
    if not result.get("success", True) and result.get("error"):
        raise RuntimeError(result["error"])
    return result
